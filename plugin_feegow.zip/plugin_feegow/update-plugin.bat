@echo off
echo Baixando nova versão...

powershell -NoProfile -ExecutionPolicy Bypass -Command "$url='https://raw.githubusercontent.com/ictbraseg/feegow-extension-chrome-update/plugin_chrome/content.js'; $destino='C:\extensions_feegow_chrome\public\content.js'; Invoke-WebRequest -Uri $url -OutFile $destino"

echo Atualizado com sucesso!
timeout /t 2 /nobreak >nul
exit
